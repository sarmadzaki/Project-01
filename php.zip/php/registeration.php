<?php

include 'db.php';

$fname = $_POST['fname'];
$lname = $_POST['lname'];
$company = $_POST['company'];
$city = $_POST['city'];
$email = $_POST['email'];
$phone = $_POST['phone'];

mysqli_query($con, "INSERT INTO users VALUES ('', '".$fname."', '".$lname."', '".$company."', '".$city."', '".$email."', '".$phone."')");

echo "Registeration Successfully Done!";


?>